# Diccionario culinario (Android) – Offline + Favoritos + Historial + Pronunciación

Esta app:
- Importa tu CSV a una base de datos local (SQLite) la primera vez.
- Funciona 100% offline.
- Guarda Favoritos y Historial localmente.
- Pronuncia el término con el motor TTS del teléfono (por idioma).

## Importante (solo móvil)
Para generar e instalar un APK necesitas compilar. La forma más fácil SIN PC es usar un servicio de build en la nube:
- Opción recomendada: Codemagic (con GitHub)

Pasos:
1) Sube el proyecto a un repositorio en GitHub.
2) Entra en Codemagic y conecta tu repositorio.
3) Configura un build Android (APK o AAB) y descarga el artefacto.
4) Instálalo en tu móvil.

## Mejorar pronunciación (offline)
La pronunciación usa el motor de texto-a-voz del sistema. Para que funcione offline:
- Ajustes Android > Idioma y entrada > Texto a voz (o Accesibilidad) 
- Descarga voces/idiomas offline para: ES, EN, DE, FR.
